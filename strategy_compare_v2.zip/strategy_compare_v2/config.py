"""
Configuration File
"""

from pathlib import Path

# =============================================================================
# PATHS
# =============================================================================

BASE_DIR = Path(__file__).resolve().parent

INPUT_DIR = BASE_DIR / "outputs"

OUTPUT_DIR = BASE_DIR / "reports"

OUTPUT_DIR.mkdir(exist_ok=True)

OUTPUT_FILE = OUTPUT_DIR / "Strategy_Comparison.xlsx"

# =============================================================================
# METRICS
# =============================================================================

PRIMARY_METRICS = [

    "Expectancy%",
    "Profit Factor",
    "Reward Risk",
    "Trades / Year",
    "Profit Velocity",
    "Signal Quality",
    "Holding Efficiency",
    "Winning Exit %",
    "Losing Exit %",
    "Edge Score",
    "Reliability Score",
    "Efficiency Score",
    "Composite Score"

]

RECOMMENDATION_COLUMN = "Recommendation"

STOCK_COLUMN = "Stock"

# =============================================================================
# SCORING WEIGHTS
# =============================================================================

WEIGHTS = {

    "Composite Score":0.30,

    "Reliability Score":0.20,

    "Edge Score":0.15,

    "Efficiency Score":0.10,

    "Expectancy%":0.10,

    "Profit Factor":0.10,

    "Reward Risk":0.05

}

GRADE_RULES = {

    90:"A+",

    80:"A",

    70:"B",

    60:"C",

    50:"D",

    0:"F"

}

RECOMMENDATION_RULES = {

    90:"Strong Buy",

    80:"Buy",

    70:"Watch",

    60:"Improve",

    50:"Avoid",

    0:"Reject"

}